from django.apps import AppConfig


class HomepageConfig(AppConfig):
    name = 'core.homepage'
